module github.com/bogdanfinn/quic-go-utls

go 1.24.1

toolchain go1.24.4

require (
	github.com/bogdanfinn/fhttp v0.6.2
	github.com/bogdanfinn/utls v1.7.4-barnius
	github.com/francoispqt/gojay v1.2.13
	github.com/prometheus/client_golang v1.19.1
	github.com/quic-go/qpack v0.5.1
	github.com/stretchr/testify v1.9.0
	go.uber.org/mock v0.5.0
	golang.org/x/crypto v0.36.0
	golang.org/x/net v0.38.0
	golang.org/x/sync v0.12.0
	golang.org/x/sys v0.31.0
	golang.org/x/tools v0.22.0
)

require (
	github.com/andybalholm/brotli v1.1.1 // indirect
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/cespare/xxhash/v2 v2.2.0 // indirect
	github.com/cloudflare/circl v1.5.0 // indirect
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/klauspost/compress v1.17.11 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/prometheus/client_model v0.5.0 // indirect
	github.com/prometheus/common v0.48.0 // indirect
	github.com/prometheus/procfs v0.12.0 // indirect
	golang.org/x/mod v0.18.0 // indirect
	golang.org/x/text v0.23.0 // indirect
	google.golang.org/protobuf v1.33.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
